/**
 * Application security utilities.
 */
package com.app.back.security;
