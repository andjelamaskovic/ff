package com.app.back.web.rest;
import com.app.back.config.Constants;
import com.app.back.domain.Nekretnina;
import com.app.back.domain.User;
import com.app.back.repository.NekretninaRepository;
import com.app.back.repository.UserRepository;
import com.app.back.security.AuthoritiesConstants;
import com.app.back.security.SecurityUtils;
import com.app.back.service.MailService;
import com.app.back.service.UserService;
import com.app.back.service.dto.AdminUserDTO;
import com.app.back.web.rest.errors.BadRequestAlertException;
import com.app.back.web.rest.errors.EmailAlreadyUsedException;
import com.app.back.web.rest.errors.LoginAlreadyUsedException;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.neo4j.Neo4jProperties.Authentication;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import tech.jhipster.web.util.HeaderUtil;
import tech.jhipster.web.util.PaginationUtil;
import tech.jhipster.web.util.ResponseUtil;


@RestController
@RequestMapping("/api/nekretnina")
public class NekretninaResource {
    

    public final NekretninaRepository nekretninaRepository;

    public final UserService userService;

    public NekretninaResource(NekretninaRepository nekretninaRepository, UserService userService){
        this.nekretninaRepository=nekretninaRepository;
        this.userService=userService;
    }
    
    @GetMapping("")
    public List<Nekretnina> finddAll(){
        return nekretninaRepository.findAll();

    }
    @GetMapping("/{id}")
    public ResponseEntity<Nekretnina> findOne(@PathVariable Long id) {
        Optional<Nekretnina> nekretnina = nekretninaRepository.findById(id);
        return nekretnina.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }
     @PostMapping("")
    public ResponseEntity<Nekretnina> createNekretnina(@RequestBody Nekretnina nekretnina) {
        String userLogin = SecurityUtils.getCurrentUserLogin().orElseThrow();
        User loggedUser = userService.getUserWithAuthoritiesByLogin(userLogin).orElseThrow();
        nekretnina.setUser(loggedUser);
        Nekretnina result = nekretninaRepository.save(nekretnina);
        return ResponseEntity.ok(result);
    }
    

    // @GetMapping("/user")
    // public List<Nekretnina> findByUser() {
    //     Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    //     User user = userRepository.findOneByLogin(authentication.getName()).orElseThrow();
    //     return nekretninaRepository.findByUser(user);
    // }

    // @PutMapping("/{id}")
    // public ResponseEntity<Nekretnina> updateNekretnina(@PathVariable Long id, @RequestBody Nekretnina nekretnina) {
    //     Optional<Nekretnina> existingNekretnina = nekretninaRepository.findById(id);
    //     if (existingNekretnina.isPresent()) {
    //         nekretnina.setId(id);
    //         nekretninaRepository.save(nekretnina);
    //         return ResponseEntity.ok(nekretnina);
    //     } else {
    //         return ResponseEntity.notFound().build();
    //     }
    // }

    // @DeleteMapping("/{id}")
    // public ResponseEntity<Void> deleteNekretnina(@PathVariable Long id) {
    //     nekretninaRepository.deleteById(id);
    //     return ResponseEntity.noContent().build();
    // }

}
