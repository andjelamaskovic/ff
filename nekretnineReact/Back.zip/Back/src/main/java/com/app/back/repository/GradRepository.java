package com.app.back.repository;

import com.app.back.domain.Grad;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GradRepository extends JpaRepository<Grad, Long> {
}
