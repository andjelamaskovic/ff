/**
 * Application management.
 */
package com.app.back.management;
