package com.app.back.domain;

import com.app.back.config.Constants;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.time.Instant;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;


@Entity
@Table(name = "nekretnina")
public class Nekretnina{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "naziv")
    private String naziv;

    @Column(name = "cijena")
    private Double cijena;

    @Column(name = "opis")
    private String opis;

    @Column(name = "lokacija")
    private String lokacija;
    @Column(name = "tip")
    private String tip;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "grad_id")
    private Grad grad;
    public Nekretnina() {
    }

    @OneToMany(mappedBy = "nekretnina", cascade = CascadeType.REMOVE, orphanRemoval = true, fetch = FetchType.EAGER)
    @JsonIgnoreProperties(value =  {"nekretnina"}, allowSetters =  true)
    private Set<Slike> slike = new HashSet<>();


    public Set<Slike> getSlike() {
        return slike;
    }
    
    public void setSlike(Set<Slike> slike) {
        this.slike = slike;
    }
    public User getUser() {
        return user;
    }



    public void setUser(User user) {
        this.user = user;
    }
    public Grad getGrad(){
        return grad;
    }
    public void setGrad(Grad grad){
        this.grad=grad;
    }
    public Long getId() {
        return id;
    }


    public void setId(Long id) {
        this.id = id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public Double getCijena() {
        return cijena;
    }

    public void setCijena(Double cijena) {
        this.cijena = cijena;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }
    public String getTip(){
        return tip;
    }
    public void setTip(String tip){
        this.tip=tip;
    }
    public String getLokacija() {
        return lokacija;
    }

    public void setLokacija(String lokacija) {
        this.lokacija = lokacija;
    }
}
