/**
 * Rest layer error handling.
 */
package com.app.back.web.rest.errors;
