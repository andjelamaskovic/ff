/**
 * Domain objects.
 */
package com.app.back.domain;
