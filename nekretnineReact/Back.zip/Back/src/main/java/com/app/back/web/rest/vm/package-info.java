/**
 * Rest layer visual models.
 */
package com.app.back.web.rest.vm;
