package com.app.back.repository;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.app.back.domain.Nekretnina;

@Repository
public interface NekretninaRepository extends JpaRepository<Nekretnina, Long> {
    
}
