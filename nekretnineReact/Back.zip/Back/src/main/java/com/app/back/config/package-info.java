/**
 * Application configuration.
 */
package com.app.back.config;
