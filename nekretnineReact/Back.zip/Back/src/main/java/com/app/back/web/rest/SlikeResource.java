package com.app.back.web.rest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import com.app.back.repository.NekretninaRepository;
import com.app.back.repository.SlikeRepository;
import com.app.back.service.UserService;

import java.nio.file.Files;
import java.util.List;
import com.app.back.domain.Nekretnina;
import com.app.back.domain.Slike;
@RestController
@RequestMapping("/api/slike")
public class SlikeResource {
    
    private final SlikeRepository slikeRepository;
    private static final String IMAGE_DIRECTORY = "src/main/resources/static/images/";
    private final NekretninaRepository nekretninaRepeository;

      public SlikeResource(SlikeRepository slikeRepository, NekretninaRepository nekretninaRepository){
        this.slikeRepository=slikeRepository;
        this.nekretninaRepeository=nekretninaRepository;
    }

    @PostMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<?> postSlike(@RequestPart("file") List<MultipartFile> files, @PathVariable Long id){
        Nekretnina nekretnina = nekretninaRepeository.findById(id).orElse(null);
        try{
            for (MultipartFile file : files){
                byte[] bytes = file.getBytes();
                Path path = Paths.get(IMAGE_DIRECTORY + file.getOriginalFilename());
                Files.write(path, bytes);

                String picturePath = file.getOriginalFilename();
                Slike slike = new Slike();
                slike.setPath(picturePath);
                slike.setNekretnina(nekretnina);
                slikeRepository.save(slike);
                return ResponseEntity.ok().body("Uspjesno");
            }
        }catch(Exception e){
            return new ResponseEntity<>("", HttpStatus.BAD_REQUEST);
        }
        return null;
    }
}
